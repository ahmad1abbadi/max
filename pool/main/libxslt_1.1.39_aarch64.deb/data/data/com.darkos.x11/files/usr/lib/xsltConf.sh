#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/data/data/com.darkos.x11/files/usr/lib"
XSLT_LIBS="-lxslt -L/data/data/com.darkos.x11/files/usr/lib -lxml2 "
XSLT_PRIVATE_LIBS="-lm"
XSLT_INCLUDEDIR="-I/data/data/com.darkos.x11/files/usr/include"
MODULE_VERSION="xslt-1.1.39"
